import React from 'react';
import Header from './Header';
import Footer from './Footer';
import AshaChat from './AshaChat';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 pt-16">{children}</main>
      <Footer />
      <AshaChat />
    </div>
  );
};

export default Layout;
