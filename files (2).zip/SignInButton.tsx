"use client";

/**
 * SignInButton
 *
 * Drop-in replacement for every "Connect Wallet" button in the app.
 * Zero blockchain language visible to the user.
 *
 * Props:
 *   variant?: "primary" | "ghost"   (default: "primary")
 *   size?:    "sm" | "md" | "lg"    (default: "md")
 *   label?:   string                (override Sign In text)
 */

import { useSignIn } from "@/hooks/useSignIn";

interface SignInButtonProps {
  variant?: "primary" | "ghost" | "secondary";
  size?: "sm" | "md" | "lg";
  label?: string;
  className?: string;
  onSignedIn?: () => void;  // called after successful sign-in
}

const sizeMap = {
  sm: "px-4 py-2 text-sm",
  md: "px-6 py-3 text-sm",
  lg: "px-8 py-4 text-base",
};

export function SignInButton({
  variant = "primary",
  size = "md",
  label,
  className = "",
  onSignedIn,
}: SignInButtonProps) {
  const { isSignedIn, isLoading, displayName, signIn, signOut } = useSignIn();

  if (isSignedIn && displayName) {
    return (
      <div className="flex items-center gap-3">
        {/* Identity indicator — shows display name, not "wallet" */}
        <div className="flex items-center gap-2 bg-bg-card border border-amber/30 rounded-xl px-4 py-2">
          <span className="w-2 h-2 rounded-full bg-amber pulse-amber" />
          <span className="text-text-primary text-sm font-medium font-body">
            {displayName}
          </span>
        </div>
        <button
          onClick={signOut}
          className="text-text-muted text-xs hover:text-text-secondary transition-colors font-body"
        >
          Sign out
        </button>
      </div>
    );
  }

  const base = "rounded-xl font-body font-semibold transition-all duration-200 flex items-center gap-2 cursor-pointer border-0";
  const variants = {
    primary:   "bg-amber text-bg hover:bg-amber/90 active:scale-[0.98]",
    secondary: "bg-primary text-white hover:bg-primary/90",
    ghost:     "bg-transparent text-text-secondary border border-border hover:border-primary-lt hover:text-text-primary",
  };

  return (
    <button
      onClick={() => { signIn(); onSignedIn?.(); }}
      disabled={isLoading}
      className={`${base} ${variants[variant]} ${sizeMap[size]} ${className}`}
    >
      {isLoading ? (
        <>
          <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full spin" />
          Signing in…
        </>
      ) : (
        label ?? "Sign In"
      )}
    </button>
  );
}
