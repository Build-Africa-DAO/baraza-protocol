/**
 * BARAZA_COLORS
 *
 * Drop-in replacement for the COLORS object in app/page.tsx.
 * Replaces Solana-green theme with Baraza civic blue brand.
 *
 * Replace the existing COLORS block at the top of page.tsx with this.
 */

export const COLORS = {
  // Backgrounds
  bg:          "#001f30",
  card:        "#003049",
  cardAlt:     "#012233",
  border:      "rgba(252,191,73,0.15)",

  // Brand
  primary:     "#219EBC",   // sky blue — interactive elements
  primaryLt:   "#8ECAE6",   // lighter sky blue — text on dark
  amber:       "#FCBF49",   // gold — primary CTA, highlights, numbers
  orange:      "#F77F00",   // orange — secondary CTA
  red:         "#D62828",   // danger, against votes
  sand:        "#EAE2B7",   // muted text on light surfaces
  success:     "#4CAF7D",

  // Text
  textPrimary:   "#F4F8FB",
  textSecondary: "#8ECAE6",
  textMuted:     "rgba(244,248,251,0.4)",
} as const;

/**
 * MIGRATION NOTES for page.tsx
 * ─────────────────────────────
 * Old value          → New value
 * COLORS.green       → COLORS.amber      (primary CTA)
 * COLORS.green       → COLORS.primary    (interactive / active states)
 * COLORS.bg (#070B12)→ COLORS.bg (#001f30)
 * COLORS.card        → COLORS.card (#003049)
 * COLORS.blue        → COLORS.primaryLt
 *
 * SPECIFIC UI CHANGES
 * ───────────────────
 * NavBar "Connect Wallet" button  → <SignInButton />
 * btn-primary background          → var(--amber) / COLORS.amber
 * .tag background                 → rgba(252,191,73,0.12)
 * .tag color                      → COLORS.amber
 * pulse-green keyframe            → pulse-amber (see globals.css)
 * vote "For" bar gradient         → COLORS.primary → COLORS.primaryLt
 * vote "Against"                  → COLORS.red (#D62828, not #FF5C5C)
 */
