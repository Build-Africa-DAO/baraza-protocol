"use client";

/**
 * useSignIn
 *
 * Wraps @solana/wallet-adapter-react behind Baraza UX language.
 * Components never see "wallet", "connect", or "publicKey" directly.
 *
 * Usage:
 *   const { isSignedIn, displayName, signIn, signOut } = useSignIn();
 */

import { useCallback } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { useWalletModal } from "@solana/wallet-adapter-react-ui";

export function useSignIn() {
  const { publicKey, connected, disconnect, connecting } = useWallet();
  const { setVisible } = useWalletModal();

  /** Open the wallet selector modal — UI calls this "Sign In" */
  const signIn = useCallback(() => {
    setVisible(true);
  }, [setVisible]);

  /** Disconnect — UI calls this "Sign Out" */
  const signOut = useCallback(async () => {
    await disconnect();
  }, [disconnect]);

  /**
   * Short display label: first 4 + last 4 chars of base58 address.
   * Used wherever UI needs to show the signed-in identity.
   */
  const displayName = publicKey
    ? `${publicKey.toBase58().slice(0, 4)}...${publicKey.toBase58().slice(-4)}`
    : null;

  return {
    isSignedIn: connected,
    isLoading: connecting,
    displayName,
    /** Raw pubkey — use only in blockchain layer, never in UI strings */
    _publicKey: publicKey,
    signIn,
    signOut,
  };
}
