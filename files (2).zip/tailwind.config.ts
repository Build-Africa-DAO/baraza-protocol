import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        /* ── Baraza brand palette ─────────────────────────── */
        "civic-blue":  "#003049",   // deep background blue
        "primary":     "#219EBC",   // interactive sky blue
        "primary-lt":  "#8ECAE6",   // lighter sky blue
        "red":         "#D62828",   // community red
        "orange":      "#F77F00",   // orange energy
        "amber":       "#FCBF49",   // gold unity (primary CTA)
        "sand":        "#EAE2B7",   // sand neutral

        /* ── Background system ───────────────────────────── */
        "bg":          "#001f30",   // page bg
        "bg-card":     "#003049",   // card surface
        "bg-card-alt": "#012233",   // darker card

        /* ── Text ────────────────────────────────────────── */
        "text-primary":   "#F4F8FB",
        "text-secondary": "#8ECAE6",
        "text-muted":     "rgba(244,248,251,0.4)",
      },
      fontFamily: {
        display: ["Unbounded", "sans-serif"],   // headlines
        body:    ["DM Sans", "sans-serif"],     // all body text
      },
      borderRadius: {
        card: "16px",
        xl2: "20px",
      },
      boxShadow: {
        amber: "0 0 0 0 rgba(252,191,73,0.4)",
        "amber-pulse": "0 0 0 8px rgba(252,191,73,0)",
      },
      animation: {
        "fade-up":    "fadeUp 0.4s ease forwards",
        "pulse-amber":"pulse-amber 2s infinite",
      },
    },
  },
  plugins: [],
};

export default config;
