"use client";

/**
 * AshaChat — Baraza AI Assistant
 *
 * Clean rewrite. Replaces keyword-matching with real Claude API (Haiku).
 * Migrated from Project_Title/src/components/AshaChat.tsx
 * Keeps: framer-motion animations, quick replies, message thread UI
 * Adds: real API, Swahili greetings, no blockchain language, typing indicator
 *
 * Model: claude-haiku-4-5-20251001  ← fast + cheap for chat
 * API route: /api/asha  (create this route — see bottom of file)
 */

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Message {
  id: string;
  role: "asha" | "user";
  text: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const INITIAL_MESSAGE: Message = {
  id: "0",
  role: "asha",
  text: "Habari! I'm Asha, your Baraza guide 👋 Ask me anything about your community, decisions, or membership.",
};

const QUICK_REPLIES = [
  "How do I propose a decision?",
  "Explain the community fund",
  "Who can join my community?",
  "How do I invite members?",
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function AshaChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  useEffect(() => {
    if (isOpen) setTimeout(() => inputRef.current?.focus(), 300);
  }, [isOpen]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), role: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setShowSuggestions(false);
    setIsLoading(true);

    try {
      const res = await fetch("/api/asha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg]
            .filter((m) => m.role !== "asha" || m.id !== "0") // exclude greeting from history
            .map((m) => ({ role: m.role === "asha" ? "assistant" : "user", content: m.text })),
        }),
      });

      const data = await res.json();
      const reply = data.reply ?? "Sorry, I couldn't get a response. Please try again.";

      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), role: "asha", text: reply },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), role: "asha", text: "Something went wrong. Please try again in a moment." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setIsOpen((v) => !v)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-lg"
        style={{ background: "var(--primary)" }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Open Asha assistant"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.span key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X size={22} color="white" />
            </motion.span>
          ) : (
            <motion.span key="open" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
              <MessageCircle size={22} color="white" />
            </motion.span>
          )}
        </AnimatePresence>
        {/* Unread dot */}
        {!isOpen && (
          <span className="absolute top-0 right-0 w-3 h-3 rounded-full border-2"
            style={{ background: "var(--amber)", borderColor: "var(--bg)" }} />
        )}
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 12 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed bottom-24 right-6 z-50 flex flex-col rounded-2xl overflow-hidden shadow-2xl"
            style={{
              width: 340,
              maxHeight: 500,
              background: "var(--bg-card)",
              border: "1px solid var(--border)",
            }}
          >
            {/* Header */}
            <div className="flex items-center gap-3 px-4 py-3" style={{ borderBottom: "1px solid var(--border)" }}>
              <div className="w-9 h-9 rounded-full flex items-center justify-center font-display font-bold text-sm"
                style={{ background: "linear-gradient(135deg, var(--primary), var(--primary-lt))", color: "white" }}>
                A
              </div>
              <div className="flex-1">
                <div className="font-display font-bold text-sm" style={{ color: "var(--text-primary)" }}>Asha</div>
                <div className="text-xs flex items-center gap-1" style={{ color: "var(--success, #4CAF7D)" }}>
                  <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: "var(--success, #4CAF7D)" }} />
                  Online · Your community guide
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} style={{ color: "var(--text-muted)" }}
                className="hover:text-white transition-colors">
                <X size={16} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3" style={{ minHeight: 0 }}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className="px-3 py-2 text-sm leading-relaxed"
                    style={{
                      maxWidth: "85%",
                      borderRadius: msg.role === "user" ? "12px 12px 4px 12px" : "4px 12px 12px 12px",
                      background: msg.role === "user" ? "var(--primary)" : "rgba(255,255,255,0.07)",
                      color: "var(--text-primary)",
                    }}
                  >
                    {msg.text}
                  </div>
                </motion.div>
              ))}

              {/* Typing indicator */}
              {isLoading && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                  <div className="px-3 py-2 rounded-xl flex gap-1 items-center"
                    style={{ background: "rgba(255,255,255,0.07)" }}>
                    {[0, 0.15, 0.3].map((delay, i) => (
                      <motion.span key={i} className="w-2 h-2 rounded-full"
                        style={{ background: "var(--text-muted)" }}
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Infinity, duration: 0.9, delay }} />
                    ))}
                  </div>
                </motion.div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick replies */}
            {showSuggestions && (
              <div className="flex flex-wrap gap-2 px-4 pb-2" style={{ borderTop: "1px solid var(--border)", paddingTop: 10 }}>
                {QUICK_REPLIES.map((q) => (
                  <button key={q} onClick={() => sendMessage(q)}
                    className="text-xs px-3 py-1.5 rounded-full transition-colors"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid var(--border)",
                      color: "var(--text-secondary)",
                    }}
                    onMouseEnter={(e) => {
                      (e.target as HTMLElement).style.borderColor = "var(--primary)";
                      (e.target as HTMLElement).style.color = "var(--primary-lt)";
                    }}
                    onMouseLeave={(e) => {
                      (e.target as HTMLElement).style.borderColor = "var(--border)";
                      (e.target as HTMLElement).style.color = "var(--text-secondary)";
                    }}
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <div className="flex gap-2 p-3" style={{ borderTop: "1px solid var(--border)" }}>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
                placeholder="Ask anything..."
                className="flex-1 text-sm px-3 py-2 rounded-lg outline-none"
                style={{
                  background: "var(--bg-card-alt)",
                  border: "1px solid var(--border)",
                  color: "var(--text-primary)",
                }}
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || isLoading}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-colors flex-shrink-0"
                style={{
                  background: input.trim() ? "var(--primary)" : "var(--border)",
                  cursor: input.trim() ? "pointer" : "not-allowed",
                }}
              >
                <Send size={15} color="white" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CREATE THIS FILE: app/api/asha/route.ts
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const ASHA_SYSTEM = `
You are Asha, a warm and knowledgeable guide for Baraza — a platform that helps
African communities manage shared funds, make decisions together, and issue 
membership cards.

Your tone: warm, direct, practical. Occasionally greet in Swahili 
(Habari, Karibu, Asante sana). Keep answers under 3 sentences.

NEVER mention: blockchain, wallet, NFT, DAO, token, crypto, gas fees, 
smart contracts, public key, seed phrase.

USE INSTEAD:
- "wallet" → "your Baraza account"
- "NFT" → "membership card"  
- "DAO" → "community"
- "mint" → "join" or "create"
- "treasury" → "community fund"
- "on-chain" → (omit entirely)
- "token" → "membership" or "contribution"

Example topics you help with:
- Creating a community (name, type, fees, rules)
- How decisions/voting work (propose, support, object)
- Community fund management (contributions, spending, transparency)  
- Inviting and approving members
- Understanding membership cards
`;

export async function POST(req: Request) {
  const { messages } = await req.json();
  
  const response = await client.messages.create({
    model: "claude-haiku-4-5-20251001",
    max_tokens: 256,
    system: ASHA_SYSTEM,
    messages,
  });

  const reply = response.content[0].type === "text" 
    ? response.content[0].text 
    : "I couldn't process that. Please try again.";

  return NextResponse.json({ reply });
}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK BREAKDOWN FOR THIS FILE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TASK 3a — Copy this file to app/components/AshaChat.tsx  [claude-sonnet-4-5]
TASK 3b — Create app/api/asha/route.ts from template above  [claude-haiku-4-5-20251001]
TASK 3c — Add ANTHROPIC_API_KEY to .env.local  [manual — Aziz does this]
TASK 3d — Import <AshaChat /> in app/page.tsx  [claude-sonnet-4-5, 1 line change]
TASK 3e — Install SDK: npm install @anthropic-ai/sdk  [manual]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/
