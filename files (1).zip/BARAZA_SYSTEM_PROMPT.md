# BARAZA PROTOCOL — MASTER SYSTEM PROMPT
# Use this in: Claude Code (terminal), Jules, or any agentic Claude session
# Model: claude-sonnet-4-5 (tasks) · claude-opus-4-5 (architecture decisions only)
# Last updated: May 2026 · Maintainer: Aziz Motomoto (@aziz_motomoto)

---

## 0. CREDIT-SAVING RULES — READ FIRST, ALWAYS

Before writing a single line of code, run this checklist:

```
[ ] Does this file already exist in the repo?
[ ] Does this component/hook already exist under a different name?
[ ] Is this logic already handled in providers.tsx, globals.css, or tailwind.config.ts?
[ ] Am I about to rewrite a file that only needs 1–3 lines changed?
```

If any answer is YES → use str_replace / patch, NOT full rewrite.
NEVER rewrite a file that is >80% unchanged.
NEVER regenerate working Anchor/Solana code unless explicitly told to.
NEVER re-scaffold Next.js boilerplate (layout.tsx, providers.tsx) unless broken.
Output ONLY the changed lines + file path. Skip unchanged files entirely.

---

## 1. REPO TRUTH — SINGLE SOURCE

**Main repo:** `baraza-protocol/` (Next.js 14, TypeScript, Tailwind, Solana)  
**Discard:** `baraza.jsx` = duplicate of page.tsx, already superseded  
**Migrate in:** `Project_Title/src/components/AshaChat.tsx` → `app/components/AshaChat.tsx`  
**Migrate in:** `Project_Title/src/components/ui/` → `app/components/ui/`  
**Anchor program:** `jules_session/programs/community_voting/` → keep separate, wire via IDL  

Do NOT create parallel implementations. One file per concern.

---

## 2. CONFIRMED BRAND TOKENS — DO NOT CHANGE THESE

```ts
// globals.css & tailwind.config.ts — LOCKED
colors: {
  "civic-blue":  "#003049",   // page bg, deep surfaces
  "red":         "#D62828",   // danger, against votes
  "orange":      "#F77F00",   // secondary CTA, accent
  "amber":       "#FCBF49",   // PRIMARY CTA, numbers, gold highlights
  "sand":        "#EAE2B7",   // muted text on light surfaces
  // Supporting UI (not in Coolors palette but approved):
  "primary":     "#219EBC",   // interactive sky blue — links, focus, active
  "primary-lt":  "#8ECAE6",   // lighter sky blue — hover states
  // Backgrounds:
  "bg":          "#001f30",   // deepest navy — html/body
  "bg-card":     "#003049",   // card surface
  "bg-card-alt": "#012233",   // darker card
}

fonts: {
  display: ["Unbounded"],   // headlines ONLY
  body:    ["DM Sans"],     // everything else
}
```

**ZERO blockchain language in UI.** Banned words in JSX/TSX user-facing strings:
- ❌ wallet, connect wallet, NFT, DAO, token, crypto, blockchain, gas, mint, on-chain
- ✅ Sign In, Sign Out, Community, Membership Card, Community Fund, Decision, Support, Object

---

## 3. ARCHITECTURE — COMPLETED (DO NOT TOUCH)

These files are DONE. Skip them unless a task explicitly names them:

```
app/layout.tsx           ✅ done — metadata, font imports, WalletProviders
app/providers.tsx        ✅ done — Phantom + Solflare adapters, devnet
app/globals.css          ✅ done — brand tokens, btn-primary, .card, .input, .tag
tailwind.config.ts       ✅ done — full brand palette + font families
hooks/useSignIn.ts       ✅ done — wraps useWallet(), exposes signIn/signOut/displayName
components/SignInButton.tsx ✅ done — primary/secondary/ghost variants
.env.example             ✅ done — Privy, Africa's Talking, LI.FI, x402, RPC keys
```

---

## 4. CURRENT TASK QUEUE (work in this order)

### TASK 1 — Split page.tsx monolith into components
**Status:** TODO  
**File:** `app/page.tsx` (788 lines, all screens inlined)  
**Action:** Extract each screen into its own file. Do NOT change logic or styles.

```
app/
  components/
    NavBar.tsx          ← extract NavBar component
    Landing.tsx         ← extract Landing screen  
    wizard/
      WizardShell.tsx   ← StepIndicator + step routing
      Step1Setup.tsx    ← community name, type, description
      Step2Membership.tsx
      Step3Veto.tsx
      Step4Payments.tsx
      Step5NFT.tsx
      Step6Launch.tsx
    Dashboard.tsx       ← dashboard screen
    AshaChat.tsx        ← MIGRATE from Project_Title/src/components/AshaChat.tsx
  page.tsx              ← becomes ~40 lines: imports + screen router only
```

**Constraint:** Replace `const connectWallet = () => { setWallet(mock) }` with `useSignIn()` hook.
Replace every `<button>Connect Wallet</button>` with `<SignInButton />`.

---

### TASK 2 — Wire Anchor program to frontend
**Status:** TODO  
**Anchor program location:** `jules_session/programs/community_voting/`  
**Program ID:** `6h6F5R5vGZJ8v8rJt5F9z4P1T2w3x4y5z6a7b8c9d0e1` (devnet)  

Steps:
1. Copy IDL (after `anchor build`) to `app/lib/idl/community_voting.json`
2. Create `app/lib/program.ts` — exports `getProgram(wallet, connection)`
3. Create `app/hooks/useCommunity.ts` — `createCommunity`, `joinCommunity`, `createDecision`, `vote`
4. Wire `useCommunity.createCommunity()` into Step6Launch.tsx deploy button
5. Wire `useCommunity.vote()` into Dashboard.tsx vote buttons

**Constraint:** All blockchain calls stay inside hooks. Zero Solana imports in UI components.

---

### TASK 3 — Asha AI panel (real Claude API)
**Status:** TODO — migrate + upgrade  
**Source:** `Project_Title/src/components/AshaChat.tsx` (203 lines, framer-motion, keyword matching)  
**Target:** `app/components/AshaChat.tsx`  

Upgrades needed:
- Replace keyword-match responses with real Anthropic API call (`claude-haiku-4-5-20251001`)
- Keep framer-motion animations (already in package.json)
- System prompt for Asha: community guide, no blockchain language, Swahili greetings
- Quick reply chips: "How do I propose a decision?", "Explain the fund", "Who can join?", "How are funds managed?"

```ts
// Asha system prompt (embed in the API call)
const ASHA_SYSTEM = `
You are Asha, a warm and knowledgeable guide for the Baraza community platform.
You help members understand how to create communities, manage funds, vote on decisions, 
and invite members. You occasionally greet in Swahili (Habari, Karibu, Asante).
NEVER mention: blockchain, wallet, NFT, DAO, token, crypto, gas fees, smart contracts.
Use instead: community fund, membership, decision, support/object, community card.
Keep answers under 3 sentences. Be warm, direct, practical.
`;
```

---

### TASK 4 — M-Pesa payment modal
**Status:** TODO  
**Trigger:** "Join Community" / "Become a Member" button  
**File to create:** `app/components/PaymentModal.tsx`  

Payment options order (mobile-money-first):
1. M-Pesa (Kenya — default, detect via browser locale/timezone)
2. Airtel Money
3. MTN MoMo
4. Bank Transfer
5. Debit/Credit Card
6. USDC (advanced)

Modal must show: membership price in KES, what membership includes, billing frequency, community card preview, success confirmation.

**Constraint:** No crypto language. "Pay with M-Pesa" not "mint with SOL".

---

### TASK 5 — GitHub deploy setup
**Status:** TODO  
**Files to create:**

```
.github/
  workflows/
    deploy.yml    ← Vercel deploy on push to main
    test.yml      ← anchor test + next build on PR
README.md         ← update with setup instructions
```

---

## 5. WHAT ALREADY EXISTS IN Project_Title — MIGRATE, DON'T REWRITE

```
AshaChat.tsx          → migrate as-is, then upgrade (Task 3)
components/ui/button  → use instead of custom btn-primary where possible
components/ui/dialog  → use for PaymentModal (Task 4)
components/ui/badge   → use for membership tiers
hooks/use-toast.ts    → use for payment confirmation toasts
```

---

## 6. ANCHOR PROGRAM — DO NOT MODIFY

The `community_voting` Rust program is correct as-is:
- `create_community` ✅
- `join_community` ✅  
- `create_decision` ✅
- `vote` ✅

Only missing: `create_treasury` instruction (add in a later sprint, not now).
Do not touch `lib.rs` unless Task 2 specifically requires a new instruction.

---

## 7. ENVIRONMENT VARIABLES — CONFIRMED KEYS NEEDED

```bash
# Required for Task 2 (Solana)
NEXT_PUBLIC_SOLANA_NETWORK=devnet
NEXT_PUBLIC_RPC_URL=https://api.devnet.solana.com

# Required for Task 3 (Asha AI)
ANTHROPIC_API_KEY=

# Required for Task 4 (M-Pesa)
AT_API_KEY=           # Africa's Talking
AT_USERNAME=          # Africa's Talking username

# Required for Task 4 (invisible wallets)
NEXT_PUBLIC_PRIVY_APP_ID=

# Required for Task 4 (fiat → USDC bridge)
LIFI_API_KEY=

# App
NEXT_PUBLIC_APP_URL=https://baraza.africa
NEXT_PUBLIC_APP_NAME=Baraza
```

---

## 8. OUTPUT FORMAT FOR EVERY TASK

Structure every response as:

```
## Files changed
- path/to/file.tsx  [MODIFIED — 12 lines changed]
- path/to/new.tsx   [NEW]

## What was reused (no output needed)
- providers.tsx ✅ untouched
- globals.css   ✅ untouched

## Changes
[only the diffs / new files]
```

Never output full files that are less than 30% changed. Use str_replace blocks.

---

## 9. GITHUB DEPLOY INSTRUCTIONS (for Aziz — run once)

```bash
# 1. Init repo (if not done)
cd baraza-protocol
git init
git remote add origin https://github.com/aziz_motomoto/baraza-protocol.git

# 2. Install deps
npm install

# 3. Copy env
cp .env.example .env.local
# Fill in your keys

# 4. Run locally
npm run dev

# 5. Deploy to Vercel
npx vercel --prod

# 6. Push to GitHub
git add .
git commit -m "feat: brand tokens, SignIn abstraction, component split"
git push -u origin main
```

---

## 10. MODEL SELECTION GUIDE

| Task | Best model | Why |
|---|---|---|
| Task 1 — component split | `claude-sonnet-4-5` | Mechanical refactor, high token volume |
| Task 2 — Anchor wiring | `claude-sonnet-4-5` | TypeScript + Solana SDK, needs speed |
| Task 3 — Asha AI | `claude-sonnet-4-5` | React component work |
| Task 4 — Payment modal | `claude-sonnet-4-5` | UI component, straightforward |
| Task 5 — GitHub CI/CD | `claude-haiku-4-5-20251001` | YAML config, cheapest |
| Architecture decisions | `claude-opus-4-5` | Only when design is unclear |
| Asha's chat responses | `claude-haiku-4-5-20251001` | Low latency, cheap per message |

**Never use Opus for mechanical tasks. Never use Haiku for multi-file refactors.**

---
