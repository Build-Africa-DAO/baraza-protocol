#!/bin/bash

# Ensure the environment is set to devnet
solana config set --url devnet

# Check if a wallet exists, if not create one
if [ ! -f ~/.config/solana/id.json ]; then
    echo "Creating a new wallet..."
    solana-keygen new --no-passphrase
fi

# Airdrop some SOL if needed (might fail on devnet if rate limited)
echo "Requesting airdrop..."
solana airdrop 2 || echo "Airdrop failed, hopefully you already have SOL."

# Build the program
echo "Building program..."
anchor build

# Deploy the program
echo "Deploying to devnet..."
anchor deploy --provider.cluster devnet

echo "Deployment complete!"
