import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { CommunityVoting } from "../target/types/community_voting";
import { expect } from "chai";

describe("community_voting", () => {
  // Configure the client to use the local cluster.
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.CommunityVoting as Program<CommunityVoting>;

  const communityName = "Test Community";
  const [communityPDA] = anchor.web3.PublicKey.findProgramAddressSync(
    [Buffer.from("community"), Buffer.from(communityName)],
    program.programId
  );

  it("Creates a community", async () => {
    await program.methods
      .createCommunity(communityName)
      .accounts({
        community: communityPDA,
        authority: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const communityAccount = await program.account.community.fetch(communityPDA);
    expect(communityAccount.name).to.equal(communityName);
    expect(communityAccount.authority.toBase58()).to.equal(provider.wallet.publicKey.toBase58());
    expect(communityAccount.memberCount.toNumber()).to.equal(0);
  });

  it("Joins a community", async () => {
    const [membershipPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("membership"), communityPDA.toBuffer(), provider.wallet.publicKey.toBuffer()],
      program.programId
    );

    await program.methods
      .joinCommunity()
      .accounts({
        membership: membershipPDA,
        community: communityPDA,
        member: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const membershipAccount = await program.account.membership.fetch(membershipPDA);
    expect(membershipAccount.member.toBase58()).to.equal(provider.wallet.publicKey.toBase58());
    expect(membershipAccount.community.toBase58()).to.equal(communityPDA.toBase58());

    const communityAccount = await program.account.community.fetch(communityPDA);
    expect(communityAccount.memberCount.toNumber()).to.equal(1);
  });

  it("Creates a decision", async () => {
    const decisionId = new anchor.BN(1);
    const description = "Should we upgrade the system?";
    const [decisionPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("decision"), communityPDA.toBuffer(), decisionId.toArrayLike(Buffer, "le", 8)],
      program.programId
    );

    const [membershipPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("membership"), communityPDA.toBuffer(), provider.wallet.publicKey.toBuffer()],
      program.programId
    );

    await program.methods
      .createDecision(decisionId, description)
      .accounts({
        decision: decisionPDA,
        community: communityPDA,
        membership: membershipPDA,
        proposer: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const decisionAccount = await program.account.decision.fetch(decisionPDA);
    expect(decisionAccount.description).to.equal(description);
    expect(decisionAccount.decisionId.toNumber()).to.equal(1);
    expect(decisionAccount.yesVotes.toNumber()).to.equal(0);
    expect(decisionAccount.noVotes.toNumber()).to.equal(0);
  });

  it("Votes on a decision", async () => {
    const decisionId = new anchor.BN(1);
    const [decisionPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("decision"), communityPDA.toBuffer(), decisionId.toArrayLike(Buffer, "le", 8)],
      program.programId
    );

    const [membershipPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("membership"), communityPDA.toBuffer(), provider.wallet.publicKey.toBuffer()],
      program.programId
    );

    const [voteRecordPDA] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("vote"), decisionPDA.toBuffer(), provider.wallet.publicKey.toBuffer()],
      program.programId
    );

    await program.methods
      .vote(true)
      .accounts({
        voteRecord: voteRecordPDA,
        decision: decisionPDA,
        membership: membershipPDA,
        community: communityPDA,
        member: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const decisionAccount = await program.account.decision.fetch(decisionPDA);
    expect(decisionAccount.yesVotes.toNumber()).to.equal(1);
    expect(decisionAccount.noVotes.toNumber()).to.equal(0);

    const voteRecordAccount = await program.account.voteRecord.fetch(voteRecordPDA);
    expect(voteRecordAccount.voteFor).to.be.true;
  });
});
