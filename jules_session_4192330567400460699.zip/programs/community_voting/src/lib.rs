use anchor_lang::prelude::*;

declare_id!("6h6F5R5vGZJ8v8rJt5F9z4P1T2w3x4y5z6a7b8c9d0e1");

#[program]
pub mod community_voting {
    use super::*;

    pub fn create_community(ctx: Context<CreateCommunity>, name: String) -> Result<()> {
        let community = &mut ctx.accounts.community;
        community.authority = ctx.accounts.authority.key();
        community.name = name;
        community.member_count = 0;
        Ok(())
    }

    pub fn join_community(ctx: Context<JoinCommunity>) -> Result<()> {
        let membership = &mut ctx.accounts.membership;
        membership.community = ctx.accounts.community.key();
        membership.member = ctx.accounts.member.key();
        membership.joined_at = Clock::get()?.unix_timestamp;

        let community = &mut ctx.accounts.community;
        community.member_count += 1;
        Ok(())
    }

    pub fn create_decision(ctx: Context<CreateDecision>, decision_id: u64, description: String) -> Result<()> {
        let decision = &mut ctx.accounts.decision;
        decision.community = ctx.accounts.community.key();
        decision.decision_id = decision_id;
        decision.description = description;
        decision.yes_votes = 0;
        decision.no_votes = 0;
        decision.bump = ctx.bumps.decision;
        Ok(())
    }

    pub fn vote(ctx: Context<Vote>, vote_for: bool) -> Result<()> {
        let vote_record = &mut ctx.accounts.vote_record;
        vote_record.decision = ctx.accounts.decision.key();
        vote_record.member = ctx.accounts.member.key();
        vote_record.vote_for = vote_for;

        let decision = &mut ctx.accounts.decision;
        if vote_for {
            decision.yes_votes += 1;
        } else {
            decision.no_votes += 1;
        }
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(name: String)]
pub struct CreateCommunity<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 4 + name.len() + 8,
        seeds = [b"community", name.as_bytes()],
        bump
    )]
    pub community: Account<'info, Community>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct JoinCommunity<'info> {
    #[account(
        init,
        payer = member,
        space = 8 + 32 + 32 + 8,
        seeds = [b"membership", community.key().as_ref(), member.key().as_ref()],
        bump
    )]
    pub membership: Account<'info, Membership>,
    #[account(mut)]
    pub community: Account<'info, Community>,
    #[account(mut)]
    pub member: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(decision_id: u64)]
pub struct CreateDecision<'info> {
    #[account(
        init,
        payer = proposer,
        space = 8 + 32 + 8 + 4 + 200 + 8 + 8 + 1,
        seeds = [b"decision", community.key().as_ref(), decision_id.to_le_bytes().as_ref()],
        bump
    )]
    pub decision: Account<'info, Decision>,
    pub community: Account<'info, Community>,
    #[account(
        seeds = [b"membership", community.key().as_ref(), proposer.key().as_ref()],
        bump
    )]
    pub membership: Account<'info, Membership>,
    #[account(mut)]
    pub proposer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Vote<'info> {
    #[account(
        init,
        payer = member,
        space = 8 + 32 + 32 + 1 + 1,
        seeds = [b"vote", decision.key().as_ref(), member.key().as_ref()],
        bump
    )]
    pub vote_record: Account<'info, VoteRecord>,
    #[account(mut)]
    pub decision: Account<'info, Decision>,
    #[account(
        seeds = [b"membership", community.key().as_ref(), member.key().as_ref()],
        bump
    )]
    pub membership: Account<'info, Membership>,
    pub community: Account<'info, Community>,
    #[account(mut)]
    pub member: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[account]
pub struct Community {
    pub authority: Pubkey,
    pub name: String,
    pub member_count: u64,
}

#[account]
pub struct Membership {
    pub community: Pubkey,
    pub member: Pubkey,
    pub joined_at: i64,
}

#[account]
pub struct Decision {
    pub community: Pubkey,
    pub decision_id: u64,
    pub description: String,
    pub yes_votes: u64,
    pub no_votes: u64,
    pub bump: u8,
}

#[account]
pub struct VoteRecord {
    pub decision: Pubkey,
    pub member: Pubkey,
    pub vote_for: bool,
}
