import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Users, TrendingUp, Vote, History, PlusCircle, CreditCard,
  ArrowLeft, Calendar, Activity, Loader2, BookUser
} from 'lucide-react';
import Layout from '@/components/Layout';
import DecisionCard from '@/components/DecisionCard';
import MembershipCard from '@/components/MembershipCard';
import LiveStatCard from '@/components/LiveStatCard';
import ActivityFeed from '@/components/ActivityFeed';
import MemberDirectory from '@/components/MemberDirectory';
import { formatKSh } from '@/lib/constants';
import { useWallet } from '@solana/wallet-adapter-react';
import {
  useCommunity,
  useDecisions,
  useMembership,
  useJoinCommunity,
} from '@/hooks/useBarazaData';

const CommunityDashboard: React.FC = () => {
  const { id = '1' } = useParams<{ id: string }>();
  const { connected, publicKey } = useWallet();
  const walletKey = publicKey?.toBase58() || null;

  // Live data hooks
  const community = useCommunity(id);
  const { active: activeDecisions, past: pastDecisions, all: allDecisions } = useDecisions(id);
  const isMember = useMembership(id, walletKey);
  const { join, isLoading: isJoining } = useJoinCommunity();

  const [activeTab, setActiveTab] = useState<'decisions' | 'members' | 'activity' | 'membership'>('decisions');
  const [showJoinModal, setShowJoinModal] = useState(false);

  if (!community) {
    return (
      <Layout>
        <section className="py-20">
          <div className="container mx-auto px-4 text-center">
            <p className="text-muted-foreground">Community not found.</p>
            <Link to="/communities" className="btn-primary mt-4 inline-block text-sm">Browse Communities</Link>
          </div>
        </section>
      </Layout>
    );
  }

  const handleJoin = async () => {
    if (!connected || !walletKey) return;
    const ok = await join(id, walletKey);
    if (ok) setShowJoinModal(false);
  };

  return (
    <Layout>
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          {/* Back */}
          <Link
            to="/communities"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            All Communities
          </Link>

          {/* Community header */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col sm:flex-row items-start gap-4 mb-8"
          >
            <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center flex-shrink-0">
              <span className="font-display text-lg font-bold text-primary">{community.image}</span>
            </div>
            <div className="flex-1">
              <h1 className="font-display text-xl md:text-2xl font-bold text-foreground mb-1">
                {community.name}
              </h1>
              <p className="text-sm text-muted-foreground mb-3">{community.description}</p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 text-primary font-medium capitalize">
                  {community.type}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  Since {new Date(community.createdAt).toLocaleDateString('en-KE', { month: 'short', year: 'numeric' })}
                </span>
                <span className="font-medium text-accent">
                  {formatKSh(community.membershipFee)}/month
                </span>
                {/* Live badge */}
                <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-semibold">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary/60" />
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-primary" />
                  </span>
                  Live
                </span>
              </div>
            </div>
            {connected && !isMember && (
              <button
                onClick={() => setShowJoinModal(true)}
                className="btn-warm text-sm flex items-center gap-2"
              >
                <CreditCard className="w-4 h-4" />
                Join Group
              </button>
            )}
          </motion.div>

          {/* Live stats grid */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8"
          >
            <LiveStatCard
              icon={TrendingUp}
              label="Community Fund"
              value={community.fundBalance}
              format={(v) => formatKSh(v)}
              color="text-accent"
              bg="bg-accent/10"
            />
            <LiveStatCard
              icon={Users}
              label="Members"
              value={community.memberCount}
              color="text-primary"
              bg="bg-primary/10"
            />
            <LiveStatCard
              icon={Vote}
              label="Active Decisions"
              value={activeDecisions.length}
              color="text-secondary"
              bg="bg-secondary/10"
              showDelta={false}
            />
            <LiveStatCard
              icon={History}
              label="Past Decisions"
              value={pastDecisions.length}
              color="text-muted-foreground"
              bg="bg-muted/50"
              showDelta={false}
            />
          </motion.div>

          {/* Tabs */}
          <div className="flex items-center gap-1 mb-6 border-b border-border/50 pb-px overflow-x-auto">
            {[
              { key: 'decisions', label: 'Decisions', icon: Vote },
              { key: 'members', label: 'Members', icon: BookUser },
              { key: 'activity', label: 'Activity', icon: Activity },
              { key: 'membership', label: 'My Membership', icon: CreditCard },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-all border-b-2 -mb-px whitespace-nowrap ${
                  activeTab === tab.key
                    ? 'text-primary border-primary'
                    : 'text-muted-foreground border-transparent hover:text-foreground'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
                {tab.key === 'activity' && (
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent/40" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
                  </span>
                )}
              </button>
            ))}
            <div className="flex-1" />
            {isMember && activeTab === 'decisions' && (
              <Link
                to={`/create-decision/${community.id}`}
                className="btn-primary text-xs flex items-center gap-1.5 px-3 py-2"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                New Decision
              </Link>
            )}
          </div>

          {/* Decisions tab */}
          {activeTab === 'decisions' && (
            <div className="space-y-8">
              {activeDecisions.length > 0 && (
                <div>
                  <h3 className="font-display text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                    Active Decisions
                    <span className="text-[10px] font-normal text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                      {activeDecisions.length}
                    </span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeDecisions.map((d, idx) => (
                      <motion.div
                        key={d.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                      >
                        <DecisionCard {...d} />
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {pastDecisions.length > 0 && (
                <div>
                  <h3 className="font-display text-sm font-semibold text-muted-foreground mb-4">Past Decisions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {pastDecisions.map((d, idx) => (
                      <motion.div
                        key={d.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                      >
                        <DecisionCard {...d} />
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {allDecisions.length === 0 && (
                <div className="baraza-card p-10 text-center">
                  <Vote className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No decisions yet. Be the first to propose one!</p>
                </div>
              )}
            </div>
          )}

          {/* Members tab */}
          {activeTab === 'members' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <MemberDirectory communityId={id} />
            </motion.div>
          )}

          {/* Activity tab */}
          {activeTab === 'activity' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="baraza-card p-4">
                <div className="flex items-center gap-2 mb-4 px-1">
                  <Activity className="w-4 h-4 text-primary" />
                  <h3 className="font-display text-sm font-semibold text-foreground">Recent Activity</h3>
                  <span className="relative flex h-2 w-2 ml-1">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary/40" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                  </span>
                </div>
                <ActivityFeed communityId={id} limit={15} />
              </div>
            </motion.div>
          )}

          {/* Membership tab */}
          {activeTab === 'membership' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-md mx-auto py-8"
            >
              {isMember ? (
                <div className="space-y-6">
                  <MembershipCard
                    communityName={community.name}
                    memberName="Community Member"
                    memberId={walletKey ? walletKey.slice(0, 8) : 'BRZ-0001'}
                    joinDate={new Date().toLocaleDateString('en-KE', { month: 'short', year: 'numeric' })}
                    communityType={community.type}
                  />
                  <div className="baraza-card p-4 text-center">
                    <p className="text-xs text-muted-foreground">
                      Your membership is active. You can vote on decisions and propose new ones.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="baraza-card p-8 text-center">
                  <CreditCard className="w-10 h-10 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-display text-base font-semibold text-foreground mb-2">
                    Not a member yet
                  </h3>
                  <p className="text-xs text-muted-foreground mb-4">
                    Join this community to get your membership card and start participating in decisions.
                  </p>
                  {connected ? (
                    <button onClick={() => setShowJoinModal(true)} className="btn-warm text-sm">
                      Join for {formatKSh(community.membershipFee)}/month
                    </button>
                  ) : (
                    <p className="text-xs text-muted-foreground">Sign in to join this community</p>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </div>
      </section>

      {/* Join modal */}
      {showJoinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            onClick={() => setShowJoinModal(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative baraza-card p-6 max-w-sm w-full"
          >
            <h3 className="font-display text-lg font-bold text-foreground mb-2">
              Join {community.name}
            </h3>
            <p className="text-xs text-muted-foreground mb-6">
              Pay the membership fee to join and start participating in community decisions.
            </p>

            <div className="baraza-card p-4 mb-6 bg-surface">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground">Membership Fee</span>
                <span className="text-sm font-bold text-accent">{formatKSh(community.membershipFee)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Billing</span>
                <span className="text-xs text-foreground">Monthly</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowJoinModal(false)}
                className="flex-1 btn-ghost text-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleJoin}
                disabled={isJoining}
                className="flex-1 btn-warm text-sm flex items-center justify-center gap-2"
              >
                {isJoining ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Joining...
                  </>
                ) : (
                  'Pay & Join'
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </Layout>
  );
};

export default CommunityDashboard;